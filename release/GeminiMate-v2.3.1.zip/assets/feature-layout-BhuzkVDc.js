import{S as o,d as Jt,i as R,a as yt,b as pe}from"./feature-reading-juHgfi62.js";const I=100,Qt=100,Mt=170,Ee=760,he=1172,Ie=760,te=308,ee=72,be=30,K=t=>Math.max(Qt,Math.min(Mt,Math.round(t))),Se=(t,e,n)=>{if(n<=e)return I;const r=(t-e)/(n-e);return K(I+r*(Mt-I))},y=(t,e,n,r=be)=>{const a=Number(t);return Number.isFinite(a)?a>=Qt&&a<=Mt?K(a):a>=r&&a<=n?Se(a,e,n):I:I},x=(t,e)=>Number((t*K(e)/I).toFixed(3)),ne=t=>{const e=K(t);return{layoutScale:e,chatStandardPx:x(Ee,e),chatDualColumnPx:x(he,e),editInputPx:x(Ie,e),sidebarExpandedPx:x(te,e),sidebarCollapsedPx:x(ee,e)}},at="geminimate-chat-width",_e="[GM-ChatWidth]",st=30,lt=70,dt=100,ge=(t,e={})=>{try{console.info(_e,{event:t,detail:e,ts:new Date().toISOString()}),Jt.log("chat-width",t,e)}catch{}};function Te(){return[".user-query-bubble-container",".user-query-container","user-query-content","user-query",'div[aria-label="User message"]','article[data-author="user"]','[data-message-author-role="user"]']}function Ne(){return["model-response",".model-response","response-container",".response-container",".presented-response-container",'[aria-label="Gemini response"]','[data-message-author-role="assistant"]','[data-message-author-role="model"]','article[data-author="assistant"]']}function Ae(){return["table-block",".table-block","table-block .table-block","table-block .table-content",".table-block.new-table-style",".table-block.has-scrollbar",".table-block .table-content",".table-block-component",".table-block-component > response-element",".table-block-component response-element",".table-block-component table-block",".table-block-component .horizontal-scroll-wrapper",".table-block-component .table-footer",".horizontal-scroll-wrapper",".table-footer"]}const we=()=>{let t=document.getElementById(at);return t||(t=document.createElement("style"),t.id=at,document.head.appendChild(t)),t};function Pt(t){const e=y(t,lt,dt,st),n=ne(e),r=`${n.chatStandardPx.toFixed(3)}px`,a=`${n.chatDualColumnPx.toFixed(3)}px`,s=we(),l=Te().join(`,
    `),b=Ne().join(`,
    `),p=Ae().join(`,
    `);ge("apply-linear-widths",{layoutScale:e,chatStandardPx:n.chatStandardPx,chatDualColumnPx:n.chatDualColumnPx}),s.textContent=`
    :root {
      --gm-chat-width-standard: ${r} !important;
      --gm-chat-width-dual-column: ${a} !important;
    }

    chat-window-content > .conversation-container,
    .chat-history-scroll-container > .conversation-container,
    .chat-history > .conversation-container,
    .conversation-container {
      max-width: var(--gm-chat-width-standard) !important;
      box-sizing: border-box !important;
    }

    ${l} {
      max-width: var(--gm-chat-width-standard) !important;
    }

    ${b} {
      max-width: var(--gm-chat-width-standard) !important;
    }

    ${p} {
      max-width: var(--gm-chat-width-dual-column) !important;
      box-sizing: border-box !important;
    }

    .horizontal-scroll-wrapper,
    .horizontal-scroll-wrapper > .table-block-component,
    .table-block-component,
    .table-block-component > response-element,
    .table-block-component response-element,
    .table-block-component table-block,
    table-block,
    table-block .table-block,
    .table-block,
    .table-block.has-scrollbar,
    .table-block.new-table-style {
      display: block !important;
      width: 100% !important;
      max-width: 100% !important;
      min-width: 0 !important;
      box-sizing: border-box !important;
    }

    table-block .table-block,
    .table-block.has-scrollbar,
    .table-block.new-table-style {
      overflow-x: hidden !important;
    }

    table-block .table-content,
    .table-block .table-content,
    .table-block-component .horizontal-scroll-wrapper,
    .horizontal-scroll-wrapper {
      width: 100% !important;
      max-width: 100% !important;
      min-width: 0 !important;
      overflow-x: auto !important;
      box-sizing: border-box !important;
    }

    table-block .table-footer,
    .table-block .table-footer,
    .table-block-component .table-footer,
    .table-footer {
      width: 100% !important;
      max-width: 100% !important;
      min-width: 0 !important;
      box-sizing: border-box !important;
    }

    model-response:has(> .deferred-response-indicator),
    .response-container:has(img[src*="sparkle"]),
    main > div:has(img[src*="sparkle"]) {
      max-width: var(--gm-chat-width-standard) !important;
    }

    .user-query-bubble-with-background {
      max-width: var(--gm-chat-width-standard) !important;
      width: fit-content !important;
    }
  `}function _n(){let t=I;chrome.storage.local.get([o.GEMINI_CHAT_WIDTH],e=>{t=y(e[o.GEMINI_CHAT_WIDTH],lt,dt,st),Pt(t)}),chrome.storage.onChanged.addListener((e,n)=>{n==="local"&&e[o.GEMINI_CHAT_WIDTH]&&(t=y(e[o.GEMINI_CHAT_WIDTH].newValue,lt,dt,st),Pt(t))}),window.addEventListener("beforeunload",()=>{const e=document.getElementById(at);e&&e.remove()},{once:!0})}const ct="geminimate-edit-input-width",Le="[GM-EditWidth]",ut=30,mt=60,ft=100,Ce=(t,e={})=>{try{console.info(Le,{event:t,detail:e,ts:new Date().toISOString()}),Jt.log("edit-width",t,e)}catch{}};function ye(){return[".query-content.edit-mode","div.edit-mode",'[class*="edit-mode"]']}const Me=()=>{let t=document.getElementById(ct);return t||(t=document.createElement("style"),t.id=ct,document.head.appendChild(t)),t};function Ot(t){const e=y(t,mt,ft,ut),n=ne(e),r=`${n.editInputPx.toFixed(3)}px`,a=`${n.sidebarExpandedPx.toFixed(3)}px`,s=`${n.sidebarCollapsedPx.toFixed(3)}px`,l=ye().join(`,
    `),b=Me();Ce("apply-linear-widths",{layoutScale:e,editInputPx:n.editInputPx,sidebarExpandedPx:n.sidebarExpandedPx,sidebarCollapsedPx:n.sidebarCollapsedPx}),b.textContent=`
    :root {
      --gm-edit-input-width: ${r} !important;
      --gm-layout-sidebar-open-baseline: ${a} !important;
      --gm-layout-sidebar-closed-baseline: ${s} !important;
    }

    ${l} {
      max-width: var(--gm-edit-input-width) !important;
      width: min(100%, var(--gm-edit-input-width)) !important;
      margin-left: auto !important;
      margin-right: auto !important;
    }

    .edit-mode .edit-container,
    .query-content.edit-mode .edit-container {
      max-width: var(--gm-edit-input-width) !important;
      width: min(100%, var(--gm-edit-input-width)) !important;
      margin-left: auto !important;
      margin-right: auto !important;
    }

    .edit-mode .mat-mdc-form-field,
    .edit-container .mat-mdc-form-field,
    .edit-mode .edit-form,
    .edit-mode .mat-mdc-text-field-wrapper,
    .edit-mode .mat-mdc-form-field-flex,
    .edit-mode .mdc-text-field,
    .edit-mode .mat-mdc-form-field-infix {
      max-width: var(--gm-edit-input-width) !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }

    .edit-mode textarea,
    .edit-container textarea,
    .edit-mode .mat-mdc-input-element,
    .edit-mode .cdk-textarea-autosize {
      max-width: 100% !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }

    input-container fieldset.input-area-container,
    chat-window input-container fieldset.input-area-container {
      max-width: var(--gm-edit-input-width) !important;
      width: min(100%, var(--gm-edit-input-width)) !important;
      margin-left: auto !important;
      margin-right: auto !important;
    }

    input-container .input-area-container,
    input-area-v2,
    input-area-v2 .input-area-container {
      width: 100% !important;
      box-sizing: border-box !important;
    }
  `}function gn(){let t=I;chrome.storage.local.get([o.GEMINI_EDIT_INPUT_WIDTH],e=>{t=y(e[o.GEMINI_EDIT_INPUT_WIDTH],mt,ft,ut),Ot(t)}),chrome.storage.onChanged.addListener((e,n)=>{n==="local"&&e[o.GEMINI_EDIT_INPUT_WIDTH]&&(t=y(e[o.GEMINI_EDIT_INPUT_WIDTH].newValue,mt,ft,ut),Ot(t))}),window.addEventListener("beforeunload",()=>{const e=document.getElementById(ct);e&&e.remove()},{once:!0})}const pt="geminimate-sidebar-width-style",J=te,Et=180,ht=540,It=(t,e,n)=>Math.min(n,Math.max(e,Math.round(t)));function ve(t){const e=`${It(t,Et,ht)}px`,n=`${ee}px`,r=`max(0px, calc(${e} - ${n}))`;return`
    :root {
      --bard-sidenav-open-width: ${e} !important;
      --bard-sidenav-closed-width: ${n} !important;
      --bard-sidenav-open-closed-width-diff: ${r} !important;
      --gv-sidenav-shift: ${r} !important;
    }

    #app-root:has(side-navigation-content > div.collapsed) {
      --gv-sidenav-shift: 0px !important;
    }

    bard-sidenav {
      --bard-sidenav-open-width: ${e} !important;
      --bard-sidenav-open-closed-width-diff: ${r} !important;
    }
  `}function Q(t){let e=document.getElementById(pt);e||(e=document.createElement("style"),e.id=pt,document.documentElement.appendChild(e)),e.textContent=ve(t)}function Tn(){let t=J;chrome.storage.local.get([o.GEMINI_SIDEBAR_WIDTH],e=>{const n=e[o.GEMINI_SIDEBAR_WIDTH];typeof n=="number"&&Number.isFinite(n)?t=It(n,Et,ht):t=J,Q(t)}),chrome.storage.onChanged.addListener((e,n)=>{if(n==="local"&&e[o.GEMINI_SIDEBAR_WIDTH]){const r=Number(e[o.GEMINI_SIDEBAR_WIDTH].newValue);Number.isFinite(r)?(t=It(r,Et,ht),Q(t)):(t=J,Q(t))}}),window.addEventListener("beforeunload",()=>{const e=document.getElementById(pt);e&&e.remove()},{once:!0})}const bt="geminimate-sidebar-auto-hide-style",xe=500,De=300,Ge=1e3,Re=200,ke=1500;let u=!1,E=null,h=null,c=null,N=null,A=null,_=null,k=null,w=null,M=!1,vt=0;function St(t){const e=window.getComputedStyle(t);if(e.display==="none"||e.visibility==="hidden")return!1;const n=t.getBoundingClientRect();return n.width>0||n.height>0}function He(){if(document.getElementById(bt))return;const t=document.createElement("style");t.id=bt,t.textContent=`
    bard-sidenav,
    bard-sidenav side-navigation-content,
    bard-sidenav side-navigation-content > div {
      transition: width 0.25s ease, transform 0.25s ease !important;
    }
  `,document.documentElement.appendChild(t)}function $e(){const t=document.querySelector('button[data-test-id="side-nav-menu-button"]');if(t)return t;const e=document.querySelector("side-nav-menu-button");return e?e.querySelector("button"):null}function xt(){if(document.body.classList.contains("mat-sidenav-opened"))return!1;if(document.querySelector("bard-sidenav side-navigation-content > div")?.classList.contains("collapsed"))return!0;const e=document.querySelector("bard-sidenav");return!!(e&&e.getBoundingClientRect().width<80)}function _t(){const t=document.querySelector("bard-sidenav");return t?St(t):!1}function Fe(){return Date.now()<vt}function oe(){for(const t of document.querySelectorAll(".mat-mdc-dialog-container"))if(St(t))return!0;for(const t of document.querySelectorAll(".mat-mdc-menu-panel"))if(St(t))return!0;return!1}function Pe(){if(c?.matches(":hover"))return!0;for(const t of document.querySelectorAll(".mat-mdc-dialog-container"))if(t.matches(":hover"))return!0;for(const t of document.querySelectorAll(".mat-mdc-menu-panel"))if(t.matches(":hover"))return!0;return!1}function Oe(t){if(!u)return;t.target.closest('[role="menuitem"], .mat-mdc-menu-item, bard-sidenav button, [data-test-id*="options"]')&&(vt=Date.now()+ke)}function Dt(){const t=$e();return t?(t.click(),!0):!1}function ie(){Fe()||oe()||Pe()||xt()||Dt()&&(M=!0)}function Be(){xt()&&(Dt(),M=!1)}function gt(){u&&(E!==null&&(clearTimeout(E),E=null),h!==null&&clearTimeout(h),h=window.setTimeout(()=>{h=null,u&&Be()},De))}function Tt(){u&&(h!==null&&(clearTimeout(h),h=null),E!==null&&clearTimeout(E),E=window.setTimeout(()=>{E=null,u&&ie()},xe))}function re(){const t=document.querySelector("bard-sidenav");return!t||!_t()?!1:(t===c||(c&&(c.removeEventListener("mouseenter",gt),c.removeEventListener("mouseleave",Tt)),c=t,t.addEventListener("mouseenter",gt),t.addEventListener("mouseleave",Tt)),!0)}function ae(){c&&(c.removeEventListener("mouseenter",gt),c.removeEventListener("mouseleave",Tt),c=null)}function tt(){if(!u)return;const t=document.querySelector("bard-sidenav");if(c&&!_t()){ae(),M=!1;return}t&&_t()&&t!==c&&re()}function Bt(){u||(u=!0,M=!1,vt=0,He(),re(),N||(N=new MutationObserver(()=>u&&tt()),N.observe(document.body,{childList:!0,subtree:!0})),A||(A=()=>{u&&(_!==null&&clearTimeout(_),_=window.setTimeout(()=>{_=null,tt()},Re))},window.addEventListener("resize",A)),w||(w=Oe,document.addEventListener("click",w,!0)),k===null&&(k=window.setInterval(tt,Ge)),setTimeout(()=>{u&&c&&!c.matches(":hover")&&!oe()&&ie()},500))}function Wt(){if(!u)return;u=!1,h!==null&&(clearTimeout(h),h=null),E!==null&&(clearTimeout(E),E=null),_!==null&&(clearTimeout(_),_=null),k!==null&&(clearInterval(k),k=null),M&&xt()&&Dt(),M=!1,ae();const t=document.getElementById(bt);t&&t.remove(),N&&(N.disconnect(),N=null),A&&(window.removeEventListener("resize",A),A=null),w&&(document.removeEventListener("click",w,!0),w=null)}function Nn(){chrome.storage.local.get({[o.GEMINI_SIDEBAR_AUTO_HIDE]:!1},t=>{t[o.GEMINI_SIDEBAR_AUTO_HIDE]&&Bt()}),chrome.storage.onChanged.addListener((t,e)=>{e==="local"&&t[o.GEMINI_SIDEBAR_AUTO_HIDE]&&(t[o.GEMINI_SIDEBAR_AUTO_HIDE].newValue?Bt():Wt())}),window.addEventListener("beforeunload",Wt,{once:!0})}const et="geminimate-font-size-scale",Ut=100,We=80,Ue=130,O=400,ze=200,Ye=900,T="default",Gt="sans-apple",q="serif-source",qe=0,Ve=8,Xe=1.75,je=.1,Ke=.2;function zt(t){const e=String(t||T);return e==="monospace"?"sans":e}function nt(t,e){return String(t||"")==="monospace"?"sans-tech":String(e||Gt)}const ot={"sans-apple":"system-ui, -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Hiragino Sans GB', 'Noto Sans SC', sans-serif","sans-sys":"'Segoe UI', 'Microsoft YaHei UI', 'Noto Sans SC', sans-serif","sans-harmony":"'HarmonyOS Sans SC', 'HarmonyOS Sans', 'PingFang SC', 'Noto Sans SC', sans-serif","sans-modern":"'MiSans', 'Alibaba PuHuiTi 3.0', 'PingFang SC', 'Noto Sans SC', sans-serif","sans-grotesk":"'Helvetica Neue', Arial, 'Noto Sans SC', sans-serif","sans-humanist":"'Source Sans 3', 'Noto Sans SC', 'Microsoft YaHei UI', sans-serif","sans-tech":"'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Courier New', monospace"},Yt={"serif-source":"'Source Han Serif SC', 'Noto Serif SC', 'Songti SC', serif","serif-traditional":"'Songti SC', SimSun, 'Noto Serif SC', serif","serif-fangsong":"FangSong, STFangsong, 'Noto Serif SC', serif","serif-kaiti":"'Kaiti SC', KaiTi, STKaiti, 'Noto Serif SC', serif","serif-newspaper":"Constantia, 'Times New Roman', STSong, 'Noto Serif SC', serif","serif-editorial":"Baskerville, 'Times New Roman', STSong, serif","serif-georgia":"Georgia, Cambria, 'Noto Serif SC', serif"},Ze=".markdown",Je=`
  .markdown table th,
  .markdown table td,
  .markdown table th > p,
  .markdown table td > p,
  .markdown table th li,
  .markdown table td li`.trim(),Qe=".query-text, .query-text-line",tn="rich-textarea p, rich-textarea [contenteditable], input-area-v2 p",en=`
  rich-textarea [contenteditable]::before,
  input-area-v2 [contenteditable]::before,
  rich-textarea [data-placeholder]::before,
  input-area-v2 [data-placeholder]::before,
  input-area-v2 textarea::placeholder`.trim(),nn=`
  .markdown strong:not(.gemini-md-underline), .markdown b:not(.gemini-md-underline),
  .markdown h1, .markdown h2, .markdown h3, .markdown h4, .markdown h5, .markdown h6,
  .query-text strong:not(.gemini-md-underline), .query-text b:not(.gemini-md-underline),
  .query-text-line strong:not(.gemini-md-underline), .query-text-line b:not(.gemini-md-underline)`.trim(),qt=".markdown .katex, .query-text .katex, .query-text-line .katex",Nt=t=>Math.min(Ue,Math.max(We,Math.round(t))),Vt=t=>Math.min(Ye,Math.max(ze,Math.round(t))),X=t=>Math.min(Ve,Math.max(qe,Math.round(t)));function on(t){return Xe+X(t)*je}function Y(t,e,n){switch(t){case"monospace":return ot["sans-tech"];case"sans":return ot[e]??ot[Gt];case"serif":return Yt[n]??Yt[q];case"default":return"inherit";default:return`'${t}', sans-serif`}}function rn(t){const n=700+(t-O);return Math.min(900,Math.max(t,n))}function an(t,e,n,r,a,s,l){const p=Nt(t)/100,i=X(l),B=on(i),f=`font-size: calc(1rem * ${p}) !important;`,d=e!==O?`font-weight: ${e} !important;`:"",Rt=e!==O?`font-variation-settings: 'wght' ${e} !important;`:"",kt=n!==T?`font-family: ${Y(n,r,a)} !important;`:"",Ht="font-synthesis: weight !important;",Z=s>0?`letter-spacing: ${(s*.01).toFixed(2)}em !important;`:"",ce=i>0?`line-height: ${B.toFixed(3)} !important;`:"",m=[],ue=[f,d,Rt,kt,Ht,Z,ce].filter(Boolean).join(`
      `);m.push(`${Ze}, ${Je}, ${Qe} {
      ${ue}
    }`);const me=[f,d,Rt,kt,Ht].filter(Boolean).join(`
      `);m.push(`${tn} {
      ${me}
    }`),m.push(`${en} {
      font-size: initial !important;
      letter-spacing: normal !important;
      line-height: normal !important;
      font-variation-settings: normal !important;
      font-family: initial !important;
      font-weight: 400 !important;
      font-synthesis: initial !important;
    }`);const W=n!==T?`
      font-family: ${Y(n,r,a)} !important;`:"",U=Z?`
      ${Z}`:"",z=`
      line-height: ${(i>0?Math.max(1.2,B-Ke):1.25).toFixed(2)} !important;`;m.push(`.markdown h1 { font-size: calc(1.75rem * ${p}) !important;${W}${U}${z}
      margin-top: 1.6em !important; margin-bottom: 0.5em !important; }`),m.push(`.markdown h2 { font-size: calc(1.5rem * ${p}) !important;${W}${U}${z}
      margin-top: 1.4em !important; margin-bottom: 0.45em !important; }`),m.push(`.markdown h3 { font-size: calc(1.2rem * ${p}) !important;${W}${U}${z}
      margin-top: 1.2em !important; margin-bottom: 0.4em !important; }`),m.push(`.markdown h4, .markdown h5, .markdown h6 { font-size: calc(1.05rem * ${p}) !important;${W}${U}${z}
      margin-top: 1.0em !important; margin-bottom: 0.35em !important; }`),n!==T&&m.push(`.timeline-preview-search input::placeholder { font-family: ${Y(n,r,a)} !important; }`);const $t=rn(e),Ft=n!==T?`font-family: ${Y(n,r,a)} !important;`:"",fe=`font-variation-settings: 'wght' ${$t} !important;`;return m.push(`${nn} {
      font-weight: ${$t} !important;${Ft?`
      ${Ft}`:""}
      ${fe}
    }`),m.push(`${qt} {
      font-weight: ${e} !important;
      font-variation-settings: normal !important;
      font-synthesis: none !important;
    }`),m.push(`${qt} * {
      font-weight: inherit !important;
      font-variation-settings: normal !important;
    }`),m.join(`
`)}function An(){let t=Ut,e=O,n=T,r=Gt,a=q,s=0,l=0;const b=()=>{let i=document.getElementById(et);i||(i=document.createElement("style"),i.id=et,document.head.appendChild(i)),i.textContent=an(t,e,n,r,a,s,l)},p=(i,B)=>{if(B!=="local")return;let f=!1;if(i[o.GEMINI_FONT_SIZE_SCALE]){const d=Number(i[o.GEMINI_FONT_SIZE_SCALE].newValue);Number.isFinite(d)&&(t=Nt(d),f=!0)}if(i[o.GEMINI_FONT_WEIGHT]){const d=Number(i[o.GEMINI_FONT_WEIGHT].newValue);Number.isFinite(d)&&(e=Vt(d),f=!0)}if(i[o.GEMINI_FONT_FAMILY]&&(n=zt(i[o.GEMINI_FONT_FAMILY].newValue),i[o.GEMINI_SANS_PRESET]||(r=nt(i[o.GEMINI_FONT_FAMILY].newValue,r)),f=!0),i[o.GEMINI_SANS_PRESET]&&(r=nt(i[o.GEMINI_FONT_FAMILY]?.newValue??n,i[o.GEMINI_SANS_PRESET].newValue),f=!0),i[o.GEMINI_SERIF_PRESET]&&(a=String(i[o.GEMINI_SERIF_PRESET].newValue||q),f=!0),i[o.GEMINI_LETTER_SPACING]){const d=Number(i[o.GEMINI_LETTER_SPACING].newValue);Number.isFinite(d)&&(s=d,f=!0)}if(i[o.GEMINI_LINE_HEIGHT]){const d=Number(i[o.GEMINI_LINE_HEIGHT].newValue);Number.isFinite(d)&&(l=X(d),f=!0)}f&&b()};chrome.storage.local.get([o.GEMINI_FONT_SIZE_SCALE,o.GEMINI_FONT_WEIGHT,o.GEMINI_FONT_FAMILY,o.GEMINI_SANS_PRESET,o.GEMINI_SERIF_PRESET,o.GEMINI_LETTER_SPACING,o.GEMINI_LINE_HEIGHT],i=>{t=Nt(Number(i[o.GEMINI_FONT_SIZE_SCALE])||Ut),e=Vt(Number(i[o.GEMINI_FONT_WEIGHT])||O),n=zt(i[o.GEMINI_FONT_FAMILY]),r=nt(i[o.GEMINI_FONT_FAMILY],i[o.GEMINI_SANS_PRESET]),a=String(i[o.GEMINI_SERIF_PRESET]||q),s=Number(i[o.GEMINI_LETTER_SPACING])||0,l=X(Number(i[o.GEMINI_LINE_HEIGHT])||0),b()}),chrome.storage.onChanged.addListener(p),window.addEventListener("beforeunload",()=>{chrome.storage.onChanged.removeListener(p),document.getElementById(et)?.remove()},{once:!0})}const Xt="geminimate-custom-fonts";function sn(t){return t.map(e=>`@font-face { font-family: '${e.name}'; src: url('${e.data}'); font-display: swap; }`).join(`
`)}function jt(t){let e=document.getElementById(Xt);e||(e=document.createElement("style"),e.id=Xt,document.head.appendChild(e)),e.textContent=sn(t)}function wn(){chrome.storage.local.get([o.GEMINI_CUSTOM_FONTS],t=>{const e=t[o.GEMINI_CUSTOM_FONTS]??[];jt(e)}),chrome.storage.onChanged.addListener((t,e)=>{if(e!=="local"||!t[o.GEMINI_CUSTOM_FONTS])return;const n=t[o.GEMINI_CUSTOM_FONTS].newValue??[];jt(n)})}const At="geminimate-paragraph-indent-style",j="gm-first-line-indent",H="data-gm-indent-applied",v="data-gm-indent-normalized",wt="data-gm-indent-original-text",se="gm-indent-body-line",ln=!1,Lt=["model-response message-content p",".model-response message-content p",'[data-message-author-role="model"] message-content p','[aria-label="Gemini response"] message-content p',"model-response .markdown p",".model-response .markdown p",'[data-message-author-role="model"] .markdown p','[aria-label="Gemini response"] .markdown p',"model-response .markdown-main-panel p",".model-response .markdown-main-panel p",'[data-message-author-role="model"] .markdown-main-panel p','[aria-label="Gemini response"] .markdown-main-panel p'].join(", "),dn=/^(?:\u7b2c\s*[\u4e00-\u9fff\d]+\s*[\u7ae0\u8282\u90e8\u5206\u8bb2]|[\u4e00-\u9fff]+\s*[\u3001.\)\uff09])\s*/,cn=/^\d+\s*[\u3001.\)\uff09]\s*$/,un=["li","ul","ol","table","blockquote","pre","code",".code-block","code-block",".gm-mermaid-diagram",'[data-gm-mermaid-host="1"]',"h1","h2","h3","h4","h5","h6","model-thoughts",".thoughts-container",".thoughts-content",".thoughts-content-expanded",".thoughts-streaming",'[data-test-id*="thought"]'].join(", ");let it=!1,S=ln,L=null,$=null,C=null,g=!1,D=null;function mn(){let t=document.getElementById(At);t||(t=document.createElement("style"),t.id=At,t.textContent=`
    .${j} {
      text-indent: 2em !important;
    }

    .${se} {
      display: block !important;
      text-indent: 2em !important;
    }
  `,document.head.appendChild(t))}function Ct(){$!==null&&(clearTimeout($),$=null)}function Kt(){C!==null&&(clearTimeout(C),C=null)}function G(t){if(!(t instanceof HTMLElement))return;const e=t.getAttribute(wt);e!==null&&(t.textContent=e,t.removeAttribute(wt),t.removeAttribute(v)),t.classList.remove(j),t.removeAttribute(H)}function V(){document.querySelectorAll(`[${H}], [${v}]`).forEach(t=>G(t))}function le(t){return yt(t)?!0:t.closest(un)!==null}function fn(t){return cn.test(t.trim())}function de(t){return t.replace(/\u00a0/g," ").trim().length>0}function pn(t){if(t.getAttribute(v)==="1"||le(t)||t.children.length>0)return;const e=(t.textContent||"").replace(/\r/g,"");if(!e.includes(`
`))return;const[n,...r]=e.split(`
`),a=n.trim(),s=r.join(`
`).trim();if(!a||!s||fn(a)||!dn.test(a)||!de(s))return;t.setAttribute(wt,e),t.setAttribute(v,"1"),t.textContent="",t.appendChild(document.createTextNode(a));const l=document.createElement("span");l.className=se,l.textContent=s,t.appendChild(l)}function En(t){const e=t.tagName.toUpperCase();if(e==="P")return!0;if(e!=="DIV"||window.getComputedStyle(t).display!=="block")return!1;const r=Array.from(t.children);return r.length===0?!0:r.every(a=>{const s=a.tagName.toUpperCase();if(s==="BR"||["B","STRONG","SPAN","A","EM","I","U","CODE","MARK","SMALL","SUB","SUP"].includes(s))return!0;const l=window.getComputedStyle(a).display;return l==="inline"||l==="inline-block"||l==="contents"})}function hn(){if(!S){V();return}const t=Array.from(document.querySelectorAll(Lt)).filter(n=>!yt(n)),e=new Set(t);t.forEach(n=>{pn(n)}),document.querySelectorAll(`[${H}], [${v}]`).forEach(n=>{n instanceof HTMLElement&&(e.has(n)||G(n))}),t.forEach(n=>{if(!En(n)){G(n);return}if(le(n)){G(n);return}if(n.getAttribute(v)==="1"){n.classList.add(j),n.setAttribute(H,"1");return}if(!de(n.innerText||n.textContent||"")){G(n);return}n.classList.add(j),n.setAttribute(H,"1")})}function F(){Ct(),$=window.setTimeout(()=>{$=null,hn()},180)}function P(){g=!0,C===null&&(C=window.setTimeout(()=>{if(C=null,!!g){if(R()){P();return}g=!1,F()}},220))}function rt(t){const e=t instanceof Element?t:t.parentElement;return!e||yt(e)?!1:e.closest(Lt)!==null||pe(e)?!0:e.querySelector(Lt)!==null}function In(t){return t.some(e=>{if(e.type==="characterData")return rt(e.target);if(rt(e.target))return!0;for(const n of Array.from(e.addedNodes))if(rt(n))return!0;return!1})}function Zt(){L||!document.body||(L=new MutationObserver(t=>{if(!(!S||t.length===0)&&In(t)){if(R()){P();return}g&&(g=!1),F()}}),L.observe(document.body,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["class","style","hidden","aria-hidden"]}))}function Ln(){it||(it=!0,mn(),chrome.storage.local.get([o.GEMINI_PARAGRAPH_INDENT_ENABLED],t=>{if(S=t[o.GEMINI_PARAGRAPH_INDENT_ENABLED]===!0,!S){V();return}if(R()){P();return}F()}),D=(t,e)=>{if(e==="local"&&t[o.GEMINI_PARAGRAPH_INDENT_ENABLED]){if(S=t[o.GEMINI_PARAGRAPH_INDENT_ENABLED].newValue===!0,!S){g=!1,Ct(),Kt(),V();return}if(R()){P();return}F()}},chrome.storage.onChanged.addListener(D),document.body?Zt():document.addEventListener("DOMContentLoaded",()=>{if(Zt(),!!S){if(R()){P();return}F()}},{once:!0}),window.addEventListener("beforeunload",()=>{L&&(L.disconnect(),L=null),D&&(chrome.storage.onChanged.removeListener(D),D=null),g=!1,Ct(),Kt(),V(),document.getElementById(At)?.remove(),it=!1},{once:!0}))}export{I as D,te as S,gn as a,Tn as b,K as c,Nn as d,An as e,wn as f,Ln as g,y as n,_n as s};
