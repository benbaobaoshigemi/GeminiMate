const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/vendor-mermaid-CfxvBQ0N.js","assets/vendor-react-B-sxFqXu.js"])))=>i.map(i=>d[i]);
const y={FOLDER_DATA:"gvFolderData",LATEX_FIXER_ENABLED:"geminimate_latex_enabled",MARKDOWN_REPAIR_ENABLED:"geminimate_markdown_enabled",MERMAID_RENDER_ENABLED:"geminimate_mermaid_enabled",SVG_RENDER_ENABLED:"geminimate_svg_render_enabled",THOUGHT_TRANSLATION_ENABLED:"geminimate_thought_translation_enabled",THOUGHT_TRANSLATION_MODE:"geminimate_thought_translation_mode",YOUTUBE_RECOMMENDATION_BLOCKER_ENABLED:"geminimate_youtube_recommendation_blocker_enabled",FORMULA_COPY_ENABLED:"geminimate_formula_copy_enabled",FORMULA_COPY_FORMAT:"geminimate_formula_copy_format",WATERMARK_REMOVER_ENABLED:"geminiWatermarkRemoverEnabled",QUOTE_REPLY_ENABLED:"gvQuoteReplyEnabled",BOTTOM_CLEANUP_ENABLED:"geminimate_bottom_cleanup_enabled",DEBUG_MODE:"geminimate_debug_mode",DEBUG_LOGS:"geminimate_debug_logs",DEBUG_FILE_LOG_ENABLED:"geminimate_debug_file_log_enabled",DEBUG_CACHE_CAPTURE_ENABLED:"geminimate_debug_cache_capture_enabled",LANGUAGE:"geminimate_language",TIMELINE_ENABLED:"geminimate_timeline_enabled",TIMELINE_WIDTH:"geminimate_timeline_width",TIMELINE_AUTO_HIDE:"geminimate_timeline_auto_hide",TIMELINE_SEARCH_INCLUDE_REPLIES:"geminimate_timeline_search_include_replies",TIMELINE_STARRED_MESSAGES:"geminiTimelineStarred",TIMELINE_SCROLL_MODE:"geminiTimelineScrollMode",GEMINI_CHAT_WIDTH:"geminimate_chat_width",GEMINI_EDIT_INPUT_WIDTH:"geminimate_edit_input_width",GEMINI_SIDEBAR_WIDTH:"geminimate_sidebar_width",GEMINI_SIDEBAR_AUTO_HIDE:"geminimate_sidebar_auto_hide",GEMINI_ZOOM_LEVEL:"geminimate_zoom_level",GEMINI_FONT_SIZE_SCALE:"geminimate_font_size_scale",GEMINI_FONT_WEIGHT:"geminimate_font_weight",GEMINI_FONT_FAMILY:"geminimate_font_family",GEMINI_SANS_PRESET:"geminimate_sans_preset",GEMINI_SERIF_PRESET:"geminimate_serif_preset",GEMINI_CUSTOM_FONTS:"geminimate_custom_fonts",GEMINI_LETTER_SPACING:"geminimate_letter_spacing",GEMINI_LINE_HEIGHT:"geminimate_line_height",GEMINI_PARAGRAPH_INDENT_ENABLED:"geminimate_paragraph_indent_enabled",GEMINI_EMPHASIS_MODE:"geminimate_emphasis_mode",WORD_RESPONSE_EXPORT_ENABLED:"geminimate_word_response_export_enabled",WORD_RESPONSE_EXPORT_MODE:"geminimate_word_response_export_mode",WORD_RESPONSE_EXPORT_PURE_BODY:"geminimate_word_response_export_pure_body",WORD_RESPONSE_EXPORT_FONT_SIZE_SCALE:"geminimate_word_response_export_font_size_scale",WORD_RESPONSE_EXPORT_LINE_HEIGHT_SCALE:"geminimate_word_response_export_line_height_scale",WORD_RESPONSE_EXPORT_LETTER_SPACING_SCALE:"geminimate_word_response_export_letter_spacing_scale",GV_FOLDER_FILTER_USER_ONLY:"gvFolderFilterUserOnly",GV_FOLDER_TREE_INDENT:"gvFolderTreeIndent",GV_ACCOUNT_ISOLATION_ENABLED:"gvAccountIsolationEnabled",GV_ACCOUNT_ISOLATION_ENABLED_GEMINI:"gvAccountIsolationEnabledGemini",GV_ACCOUNT_PROFILE_MAP:"gvAccountProfileMap"},Gr=e=>e===!0||e==="true"||e===1||e==="1",Pr=e=>e==="replace"?"replace":"compare",gn=["model-response",".model-response",'[data-message-author-role="model"]','[aria-label="Gemini response"]',".presented-response-container",".response-container"].join(", "),hn=["model-response",".model-response",'[data-message-author-role="model"]','[aria-label="Gemini response"]',".response-container"].join(", "),pn="停止生成",fn=["model-thoughts",'[data-test-id="thoughts-content"]',".thoughts-container",".thoughts-content",".thoughts-content-expanded",".thoughts-streaming",".gm-thought-translation-layout",".gm-thought-translation",'[data-gm-thought-replacement="1"]'].join(", "),Rt=["model-response .deferred-response-indicator",".model-response .deferred-response-indicator",'[data-message-author-role="model"] .deferred-response-indicator','[aria-label="Gemini response"] .deferred-response-indicator',".response-container .deferred-response-indicator",'button[aria-label*="Stop generating"]','button[aria-label*="Stop response"]',`button[aria-label*="${pn}"]`,'[data-test-id*="stop"][data-test-id*="response"]','[data-test-id*="stop"][data-test-id*="generate"]'].join(", "),We=e=>e?e instanceof Element?e:e.parentElement:null,Dt=e=>{const t=We(e);return t?t.closest(gn):null},bn=e=>{const t=We(e);return t?t.closest(hn)??Dt(t):null},qr=e=>{const t=We(e);return t?t.closest(fn)!==null:!1},z=e=>Dt(e)!==null,En=e=>{const t=bn(e);return!t||t.querySelector(Rt)!==null?!1:t.querySelector("message-actions")!==null},Br=(e=document)=>e.querySelector(Rt)!==null,Le=2e3,xe=`${y.DEBUG_LOGS}:`,at=e=>{if(e!==void 0)try{return JSON.parse(JSON.stringify(e))}catch{return String(e)}};class P{static instance;enabled=!1;initialized=!1;context="unknown";logsStorageKey=`${xe}unknown`;logs=[];flushTimer=null;storageListener=null;static getInstance(){return P.instance||(P.instance=new P),P.instance}async init(t){if(this.context=t,this.logsStorageKey=`${xe}${this.normalizeContext(t)}`,!this.initialized){this.initialized=!0;try{const n=await chrome.storage.local.get([y.DEBUG_MODE,this.logsStorageKey,y.DEBUG_LOGS]);this.enabled=n[y.DEBUG_MODE]===!0;const r=n[this.logsStorageKey]??n[y.DEBUG_LOGS];this.logs=Array.isArray(r)?r.slice(-Le).map(o=>at(o)):[]}catch(n){console.warn("[GeminiMate][Debug] Failed to initialize debug service from storage",n),this.enabled=!1,this.logs=[]}this.storageListener=(n,r)=>{if(r!=="local")return;const o=n[y.DEBUG_MODE];o&&(this.enabled=o.newValue===!0,console.info("[GeminiMate][Debug] Debug mode changed",{enabled:this.enabled}),this.enabled&&this.log("debug","mode-enabled",{context:this.context}))},chrome.storage.onChanged.addListener(this.storageListener),console.info("[GeminiMate][Debug] Debug service initialized",{context:this.context,enabled:this.enabled})}}isEnabled(){return this.enabled}log(t,n,r){if(!this.enabled)return;const o={id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,ts:new Date().toISOString(),source:t,action:n,context:this.context,detail:at(r)};this.logs.push(o),this.logs.length>Le&&(this.logs=this.logs.slice(-Le)),this.forwardToBackground(o),this.scheduleFlush()}async clearLogs(){this.logs=[];try{const t=await chrome.storage.local.get(null),n=Object.keys(t).filter(r=>r.startsWith(xe));n.length>0&&await chrome.storage.local.remove(n),await chrome.storage.local.set({[y.DEBUG_LOGS]:[]})}catch(t){console.warn("[GeminiMate][Debug] Failed to clear debug logs",t)}}scheduleFlush(){this.flushTimer===null&&(this.flushTimer=setTimeout(()=>{this.flushTimer=null,this.flush()},250))}async flush(){try{await chrome.storage.local.set({[this.logsStorageKey]:this.logs})}catch(t){console.warn("[GeminiMate][Debug] Failed to flush debug logs",t)}}normalizeContext(t){const n=t.trim().toLowerCase().replace(/[^a-z0-9_-]+/g,"-");return n.length>0?n:"unknown"}forwardToBackground(t){try{if(!chrome?.runtime?.id)return;const n={type:"gm.debug.ingest",entry:t};chrome.runtime.sendMessage(n)}catch{}}}const Tn=P.getInstance(),_n="modulepreload",yn=function(e){return"/"+e},it={},Sn=function(t,n,r){let o=Promise.resolve();if(n&&n.length>0){let l=function(c){return Promise.all(c.map(u=>Promise.resolve(u).then(g=>({status:"fulfilled",value:g}),g=>({status:"rejected",reason:g}))))};document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),i=a?.nonce||a?.getAttribute("nonce");o=l(n.map(c=>{if(c=yn(c),c in it)return;it[c]=!0;const u=c.endsWith(".css"),g=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${c}"]${g}`))return;const d=document.createElement("link");if(d.rel=u?"stylesheet":_n,u||(d.as="script"),d.crossOrigin="",d.href=c,i&&d.setAttribute("nonce",i),document.head.appendChild(d),u)return new Promise((C,we)=>{d.addEventListener("load",C),d.addEventListener("error",()=>we(new Error(`Unable to preload CSS for ${c}`)))})}))}function s(a){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=a,window.dispatchEvent(i),!i.defaultPrevented)throw a}return o.then(a=>{for(const i of a||[])i.status==="rejected"&&s(i.reason);return t().catch(s)})},Re="gm-mermaid-style",w="gm-mermaid-diagram",A="gm-mermaid-toggle",f="gm-mermaid-toggle-button",ze="gm-code-download-button",kt="gm-code-share-button",x="gm-code-action-button",L="data-gm-mermaid-host",Y="data-gm-code-download",he="data-gm-code-share",_e="data-gm-mermaid-view",De="data-gm-mermaid-code",de="data-gm-mermaid-processing",ke="data-gm-mermaid-font";let se=null,lt=!1,pe=!1,F=!1,ue=!0,q=null,D=null;const fe=new Set;let K=null,me=null;const It="'Google Sans Flex', 'Google Sans', 'Helvetica Neue', Roboto, 'PingFang SC', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif";let _=It;const ct=new WeakSet,dt=new WeakSet,ut=new WeakSet,mt=new WeakSet,Cn=new Set(["代码段","代码","代码块","示例","示例代码","code","code snippet","snippet","example","sample","text","plain","plaintext","raw","output","result"]),wn=["%%","graph","flowchart","sequenceDiagram","classDiagram","stateDiagram","erDiagram","gantt","pie","gitGraph","journey","mindmap","timeline","zenuml","quadrantChart","requirementDiagram","requirement","sankey-beta","sankey","C4Context","C4Container","C4Component","C4Dynamic","C4Deployment","xychart-beta","xychart","block-beta","block","packet-beta","packet","architecture-beta","architecture","kanban","radar-beta","treemap"],Ln={bash:"sh",shell:"sh",sh:"sh",zsh:"sh",powershell:"ps1",ps1:"ps1",python:"py",py:"py",javascript:"js",js:"js",typescript:"ts",ts:"ts",tsx:"tsx",jsx:"jsx",json:"json",html:"html",css:"css",scss:"scss",sass:"sass",less:"less",markdown:"md",md:"md",yaml:"yml",yml:"yml",xml:"xml",sql:"sql",c:"c",cpp:"cpp","c++":"cpp",csharp:"cs",cs:"cs",java:"java",kotlin:"kt",go:"go",rust:"rs",ruby:"rb",php:"php",swift:"swift",dart:"dart",mermaid:"mmd"},xn=`
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M12 3a1 1 0 0 1 1 1v8.59l2.3-2.29a1 1 0 1 1 1.4 1.41l-4 4a1 1 0 0 1-1.4 0l-4-4a1 1 0 0 1 1.4-1.41L11 12.59V4a1 1 0 0 1 1-1Zm-7 14a1 1 0 0 1 1 1v1h12v-1a1 1 0 1 1 2 0v2a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1Z" fill="currentColor"/>
  </svg>
`,An=`
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M14 4h6v6h-2V7.41l-7.29 7.3-1.42-1.42L16.59 6H14V4Z" fill="currentColor"/>
    <path d="M5 5h6v2H7v10h10v-4h2v6H5V5Z" fill="currentColor"/>
  </svg>
`,p=(e,t)=>{Tn.log("mermaid",e,t),console.info("[GM-TRACE][Mermaid]",e,t??{})},$t=e=>e.replace(/[\u00A0\u2002\u2003\u2009\u3000]/g," ").replace(/[\u200B\u200C\u200D\uFEFF]/g,""),Gt=()=>It,vn=()=>{const e=Gt();return e===_?!1:(_=e,pe=!1,!0)},Nn=async()=>{if(!document.fonts?.ready)return;const e=document.fonts.ready;await Promise.race([e,new Promise(t=>{window.setTimeout(t,1200)})])},Mn=()=>document.body.classList.contains("dark-theme")||document.body.classList.contains("dark")||document.body.getAttribute("data-theme")==="dark"||document.body.getAttribute("data-color-scheme")==="dark"||document.documentElement.classList.contains("dark")||document.documentElement.classList.contains("dark-theme")||document.documentElement.getAttribute("data-theme")==="dark"||document.documentElement.getAttribute("data-color-scheme")==="dark"||window.matchMedia("(prefers-color-scheme: dark)").matches,On=e=>e?Cn.has(e.toLowerCase()):!0,Rn=e=>{const t=$t(e).trim();if(t.length<20||!wn.some(a=>t.toLowerCase().startsWith(a.toLowerCase())))return!1;const r=t.split(`
`).filter(a=>a.trim().length>0);if(r.length<2)return!1;const o=r[r.length-1].trim();return!["-->","---","-.","==>",":::","[","(","{","|","&",","].some(a=>o.endsWith(a))},Dn=()=>{if(document.getElementById(Re))return;const e=document.createElement("style");e.id=Re,e.textContent=`
    .${A} {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px;
      margin-inline-end: 6px;
      border-radius: 999px;
      border: 1px solid rgba(148, 163, 184, 0.22);
      background: rgba(248, 250, 252, 0.88);
    }

    .code-block-decoration .buttons {
      display: inline-flex !important;
      align-items: center !important;
      justify-content: flex-end !important;
      flex-wrap: nowrap !important;
      gap: 6px !important;
      margin-left: auto !important;
    }

    .${A} {
      order: 1;
      flex: 0 0 auto;
    }

    .${kt} {
      order: 2;
      flex: 0 0 auto;
    }

    .${ze} {
      order: 3;
      flex: 0 0 auto;
    }

    .code-block-decoration .buttons > .copy-button,
    .code-block-decoration .buttons > button.copy-button {
      order: 4;
      flex: 0 0 auto;
    }

    .${f} {
      border: none;
      background: transparent;
      color: #475569;
      border-radius: 999px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 600;
      line-height: 1;
      padding: 6px 10px;
      transition: all 160ms ease;
    }

    .${f}.active {
      background: rgba(59, 130, 246, 0.16);
      color: #1d4ed8;
    }

    .${x} {
      width: 32px;
      height: 32px;
      border: none;
      border-radius: 999px;
      padding: 0;
      background: transparent;
      color: var(--gem-sys-color--on-surface-variant, #5f6368);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      vertical-align: middle;
      line-height: 1;
      transition: background-color 160ms ease, color 160ms ease, opacity 160ms ease;
    }

    .${x}:hover {
      background: rgba(148, 163, 184, 0.14);
      color: var(--gem-sys-color--on-surface, #111827);
    }

    .${x}:disabled {
      cursor: not-allowed;
      opacity: 0.45;
    }

    .${x} svg {
      width: 18px;
      height: 18px;
      display: block;
      fill: currentColor;
    }

    .${w} {
      display: none;
      padding: 16px 18px 18px;
      overflow: auto;
      text-align: center;
      cursor: zoom-in;
      border-top: 1px solid rgba(148, 163, 184, 0.16);
    }

    .${w} svg {
      max-width: 100%;
      height: auto;
      overflow: visible !important;
    }

    .${w} .label,
    .${w} .edgeLabel,
    .${w} foreignObject,
    .${w} foreignObject * {
      overflow: visible !important;
    }

    .gm-mermaid-render-error {
      padding: 20px;
      text-align: center;
      color: #64748b;
    }

    .gm-mermaid-render-error strong {
      display: block;
      margin-bottom: 8px;
      color: #334155;
    }

    .gm-mermaid-modal {
      position: fixed;
      inset: 0;
      z-index: 2147483646;
      background: rgba(2, 6, 23, 0.84);
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transition: opacity 160ms ease;
    }

    .gm-mermaid-modal.visible {
      opacity: 1;
    }

    .gm-mermaid-modal-content {
      max-width: min(92vw, 1600px);
      max-height: 88vh;
      overflow: auto;
      background: rgba(255, 255, 255, 0.96);
      border: 1px solid rgba(148, 163, 184, 0.22);
      border-radius: 20px;
      box-shadow: 0 24px 60px rgba(15, 23, 42, 0.3);
      padding: 20px;
    }

    .gm-mermaid-modal-close {
      position: fixed;
      top: 18px;
      right: 18px;
      width: 40px;
      height: 40px;
      border: none;
      border-radius: 999px;
      cursor: pointer;
      font-size: 18px;
      color: white;
      background: rgba(15, 23, 42, 0.66);
    }

    .dark-theme .${A},
    html.dark .${A},
    body.dark .${A} {
      background: rgba(15, 23, 42, 0.72);
      border-color: rgba(148, 163, 184, 0.18);
    }

    .dark-theme .${f},
    html.dark .${f},
    body.dark .${f} {
      color: rgba(226, 232, 240, 0.88);
    }

    .dark-theme .${f}.active,
    html.dark .${f}.active,
    body.dark .${f}.active {
      color: #93c5fd;
      background: rgba(59, 130, 246, 0.2);
    }

    .dark-theme .${x},
    html.dark .${x},
    body.dark .${x} {
      color: rgba(226, 232, 240, 0.88);
    }
  `,document.head.appendChild(e)},W=e=>{const t=e.closest(".code-block, code-block");if(!t)return null;const n=[e,e.closest("pre"),t];for(const a of n){if(!a)continue;const i=a.getAttribute("data-language")||a.getAttribute("data-lang")||a.getAttribute("lang");if(i?.trim())return i.trim().toLowerCase();const c=(a instanceof HTMLElement?a.className:a.getAttribute("class")||"").match(/(?:language|lang)-([a-z0-9+#._-]+)/i);if(c?.[1])return c[1].toLowerCase()}const r=t.querySelector(".code-block-decoration");return r&&r.querySelector(":scope > span")?.textContent?.trim().toLowerCase()||null},Pt=async()=>{if(se)return se;if(lt)return null;try{return se=(await Sn(()=>import("./vendor-mermaid-CfxvBQ0N.js").then(t=>t.m),__vite__mapDeps([0,1]))).default,se}catch(e){return lt=!0,p("load-failed",{error:String(e)}),null}},qt=async()=>{if(pe)return!0;const e=await Pt();if(!e)return!1;const t=Mn();return _=Gt(),e.initialize({startOnLoad:!1,theme:t?"dark":"default",securityLevel:"loose",fontFamily:_,themeVariables:{fontFamily:_,darkMode:t,background:t?"#0b1020":"#ffffff",primaryColor:t?"#1f2937":"#eceff5",primaryTextColor:t?"#e5e7eb":"#1f2937",secondaryColor:t?"#111827":"#f8fafc",tertiaryColor:t?"#0f172a":"#ffffff",lineColor:t?"#cbd5e1":"#374151",clusterBkg:t?"#111827":"#e0f2fe",clusterBorder:t?"#94a3b8":"#0f766e",edgeLabelBackground:t?"#111827":"#f8fafc"},flowchart:{htmlLabels:!1,curve:"basis"},state:{useMaxWidth:!1},sequence:{useMaxWidth:!1},logLevel:5}),pe=!0,!0},J=e=>e.replace(/\r\n/g,`
`).replace(/\r/g,`
`),Bt=e=>e.closest(".code-block, code-block"),kn=e=>e.querySelector(".code-block-decoration"),Ve=e=>{const t=kn(e);if(!t)return null;const n=t.querySelector(":scope > .buttons");if(n instanceof HTMLElement)return n;const r=document.createElement("div");return r.className="buttons",t.appendChild(r),r},Ke=e=>e.querySelector(".code-block-decoration .buttons > .copy-button, .code-block-decoration .buttons > button.copy-button"),$=e=>e.querySelector('code[data-test-id="code-content"]')??e.querySelector(".formatted-code-block-internal-container code")??e.querySelector("pre code")??e.querySelector("code.code-container"),Xe=(e,t)=>e.querySelector(".formatted-code-block-internal-container")??t?.closest(".formatted-code-block-internal-container")??t?.closest("pre")??t??null,O=e=>e.querySelector(`.${w}`),In=e=>{const t=e.querySelector("defs")??e.insertBefore(document.createElementNS("http://www.w3.org/2000/svg","defs"),e.firstChild);let n=t.querySelector('style[data-gm-mermaid-font="1"]');n||(n=document.createElementNS("http://www.w3.org/2000/svg","style"),n.setAttribute("data-gm-mermaid-font","1"),t.appendChild(n)),n.textContent=`
    text, tspan, .label, .nodeLabel, .edgeLabel, foreignObject, foreignObject * {
      font-family: ${_} !important;
    }
    .label, .edgeLabel, foreignObject, foreignObject * {
      overflow: visible !important;
      line-height: 1.25 !important;
    }
    foreignObject div, foreignObject span, foreignObject p {
      margin: 0 !important;
      padding: 0 !important;
      background: transparent !important;
      border: 0 !important;
      box-shadow: none !important;
      color: inherit !important;
    }
  `},Ut=e=>{const t=e.cloneNode(!0);if(!(t instanceof SVGElement))return e.outerHTML;t.getAttribute("xmlns")||t.setAttribute("xmlns","http://www.w3.org/2000/svg"),t.getAttribute("xmlns:xlink")||t.setAttribute("xmlns:xlink","http://www.w3.org/1999/xlink"),t.style.setProperty("font-family",_,"important"),t.style.setProperty("overflow","visible","important");const n=t.querySelector("defs")??t.insertBefore(document.createElementNS("http://www.w3.org/2000/svg","defs"),t.firstChild),r=document.createElementNS("http://www.w3.org/2000/svg","style");return r.textContent=`
    text, tspan, .label, .nodeLabel, .edgeLabel, foreignObject, foreignObject * {
      font-family: ${_} !important;
    }
    .label, .edgeLabel, foreignObject, foreignObject * {
      overflow: visible !important;
      line-height: 1.25 !important;
    }
    foreignObject div, foreignObject span, foreignObject p {
      margin: 0 !important;
      padding: 0 !important;
      background: transparent !important;
      border: 0 !important;
      box-shadow: none !important;
      color: inherit !important;
    }
  `,n.appendChild(r),new XMLSerializer().serializeToString(t)},gt=e=>{const t=e.querySelector("svg");t instanceof SVGElement&&(t.style.setProperty("font-family",_,"important"),t.style.setProperty("overflow","visible","important"),In(t),t.querySelectorAll(".label, .edgeLabel, foreignObject, foreignObject *").forEach(n=>{if(n instanceof SVGElement){n.style.setProperty("overflow","visible","important");return}n instanceof HTMLElement&&(n.style.setProperty("overflow","visible","important"),n.style.setProperty("line-height","1.25","important"))}))},ht=(e,t)=>{ct.has(e)||(e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),$n(t)}),ct.add(e))},ae=(e,t,n)=>{ut.has(e)||(e.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),Vt(t,n)}),ut.add(e))},Ie=e=>{mt.has(e)||(e.addEventListener("click",()=>{e.querySelector("svg")&&Bn(e.innerHTML)}),mt.add(e))},pt=()=>new Date().toISOString().replace(/[:.]/g,"-").replace("T","_").replace("Z",""),Ft=e=>{const t=(e??"").trim().toLowerCase();return t?Ln[t]??"txt":"txt"},ft=(e,t,n)=>{const r=new Blob(e,{type:n}),o=URL.createObjectURL(r),s=document.createElement("a");s.href=o,s.download=t,s.style.display="none",document.body.appendChild(s),s.click(),s.remove(),window.setTimeout(()=>URL.revokeObjectURL(o),1e3)},$e=e=>e.getAttribute(_e)==="code"?"code":"diagram",ee=e=>{const t=e.querySelector(`[${Y}="1"]`);if(!t)return;const n=$(e);J(n?.textContent||"");const r=W(n??e),s=e.getAttribute(L)==="1"&&$e(e)==="diagram",a=O(e)?.querySelector("svg");if(s&&a instanceof SVGElement){t.disabled=!1,t.title="下载 Mermaid 图像",t.setAttribute("aria-label","下载 Mermaid 图像");return}t.disabled=!1;const i=Ft(r);t.title=`下载代码 (.${i})`,t.setAttribute("aria-label",`下载代码 (.${i})`)},$n=e=>{const t=$(e),n=J(t?.textContent||""),r=W(t??e),o=e.getAttribute(L)==="1",s=o&&$e(e)==="diagram",a=O(e)?.querySelector("svg");if(s&&a instanceof SVGElement){const u=Ut(a),g=`geminimate-mermaid-${pt()}.svg`;ft([u],g,"image/svg+xml;charset=utf-8"),p("download-diagram",{filename:g,view:"diagram"});return}if(!n.trim()){p("download-skipped-empty",{language:r,mermaidHost:o});return}const i=Ft(r),l=`geminimate-code-${pt()}.${i}`;ft([n],l,i==="json"?"application/json;charset=utf-8":i==="svg"?"image/svg+xml;charset=utf-8":"text/plain;charset=utf-8"),p("download-code",{filename:l,language:r,view:o?$e(e):"code"})},Ae=(e,t)=>{if(!e.trim())return p("share-window-open-failed",{reason:"empty-html"}),!1;try{const n=chrome.runtime.getURL("sandbox/runner.html"),r=window.open(n,"_blank");if(!r)return p("share-window-open-failed",{reason:"window-open-blocked"}),!1;const o=s=>{s.source!==r||s.data?.type!=="RUNNER_READY"||(window.removeEventListener("message",o),r.postMessage({type:"PREVIEW_HTML",html:e,title:t},"*"),p("share-window-opened",{title:t,htmlLength:e.length}))};return window.addEventListener("message",o),!0}catch(n){return p("share-window-open-failed",{reason:"send-message-exception",error:String(n)}),!1}},ve=(e,t,n)=>`<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${t}</title>
  </head>
  <body style="${n}">${e}</body>
</html>`,Ht=e=>/<\s*svg\b/i.test(e),jt=e=>/<\s*(?:!doctype|html|head|body|script|style|div|span|main|section|article|canvas|iframe)\b/i.test(e),Gn=e=>{const t=$(e),n=J(t?.textContent||""),r=W(t??e),o=e.getAttribute(L)==="1",s=O(e)?.querySelector("svg");if(o&&s instanceof SVGElement){const l=Ut(s),c=ve(l,"Mermaid Share","margin:0;padding:24px;background:#0b1020;display:flex;justify-content:center;align-items:flex-start;");Ae(c,"Mermaid Share");return}if(!n.trim())return;const a=r==="svg"||Ht(n),i=r==="html"||jt(n);if(p("share-detect",{language:r,isMermaidHost:o,isSvgSource:a,isHtmlSource:i,sourceLength:n.length}),i){const l=/<\s*(?:!doctype|html|head|body)\b/i.test(n)?n:ve(n,"HTML Share","margin:0;padding:24px;background:#f8fafc;color:#0f172a;");Ae(l,"HTML Share");return}if(a){const l=ve(n,"SVG Share","margin:0;padding:24px;background:#f8fafc;display:flex;justify-content:center;");Ae(l,"SVG Share");return}},Wt=(e,t,n,r)=>{const o=document.createElement("button");return o.type="button",o.className=`${x} ${r}`,o.innerHTML=t,o.title=e,o.setAttribute("aria-label",e),o.setAttribute(n,"1"),o},bt=(e,t)=>{dt.has(e)||(e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Gn(t)}),dt.add(e))},te=e=>{const t=e.querySelector(`[${he}="1"]`);if(!t)return;const n=$(e),r=J(n?.textContent||""),o=W(n??e),s=e.getAttribute(L)==="1",a=O(e)?.querySelector("svg")instanceof SVGElement,i=s&&a||o==="html"||o==="svg"||jt(r)||Ht(r);t.disabled=!i,t.title=i?"分享到新窗口":"当前代码类型不支持分享预览",t.setAttribute("aria-label",t.title)},Ge=e=>{const t=Ve(e);if(!t)return;let n=t.querySelector(`[${he}="1"]`);if(n)bt(n,e);else{const r=Ke(e);n=Wt("分享到新窗口",An,he,kt),bt(n,e),r?t.insertBefore(n,r):t.appendChild(n),p("download-button-inserted",{language:W($(e)??e)})}te(e)},Pe=e=>{const t=Ve(e);if(!t)return;let n=t.querySelector(`[${Y}="1"]`);if(n)ht(n,e);else{const r=Ke(e);n=Wt("下载代码",xn,Y,ze),ht(n,e),r?t.insertBefore(n,r):t.appendChild(n)}ee(e),te(e)},zt=e=>e.querySelector(`.${A}`),Vt=(e,t)=>{const n=O(e),r=Xe(e,$(e)??void 0),o=t==="diagram"&&n?"diagram":"code";e.setAttribute(_e,o),n&&(n.style.display=o==="diagram"?"block":"none"),r&&(r.style.display=o==="diagram"?"none":""),e.querySelectorAll(`.${f}`).forEach(a=>{a.classList.toggle("active",a.dataset.view===o)}),ee(e),p("view-updated",{view:o,mermaidHost:e.getAttribute(L)==="1"})},Pn=(e,t)=>{let n=O(e);return n?(Ie(n),n):(n=document.createElement("div"),n.className=w,Ie(n),t.parentElement?.insertBefore(n,t),n)},Et=e=>{const t=Ve(e);if(!t)return;const n=zt(e);if(n){const c=n.querySelector(`.${f}[data-view="diagram"]`),u=n.querySelector(`.${f}[data-view="code"]`);if(c&&u){ae(c,e,"diagram"),ae(u,e,"code");return}n.remove()}const r=document.createElement("div");r.className=A;const o=document.createElement("button");o.type="button",o.className=`${f} active`,o.dataset.view="diagram",o.textContent="图表";const s=document.createElement("button");s.type="button",s.className=f,s.dataset.view="code",s.textContent="代码",ae(o,e,"diagram"),ae(s,e,"code"),r.append(o,s);const a=t.querySelector(`[${Y}="1"]`),i=Ke(e),l=a??i;l?t.insertBefore(r,l):t.appendChild(r)},qn=(e,t)=>{const n=t.length>240?`${t.slice(0,240)}...`:t;e.innerHTML=`
    <div class="gm-mermaid-render-error">
      <strong>Mermaid 渲染失败</strong>
      <div>${n}</div>
      <div style="margin-top:8px;font-size:12px;">你仍然可以切回代码视图或直接下载源码。</div>
    </div>
  `},qe=(e,t)=>{O(e)?.remove(),zt(e)?.remove(),t?(e.querySelector(`[${he}="1"]`)?.remove(),e.querySelector(`[${Y}="1"]`)?.remove()):(ee(e),te(e));const o=Xe(e,$(e)??void 0);o&&(o.style.display=""),e.removeAttribute(L),e.removeAttribute(_e),e.removeAttribute(De),e.removeAttribute(ke),e.removeAttribute(de)},ge=()=>{if(me&&(document.removeEventListener("keydown",me),me=null),!K)return;const e=K;e.classList.remove("visible"),K=null,window.setTimeout(()=>e.remove(),160)},Bn=e=>{if(K)return;const t=document.createElement("div");t.className="gm-mermaid-modal";const n=document.createElement("button");n.className="gm-mermaid-modal-close",n.type="button",n.textContent="×";const r=document.createElement("div");r.className="gm-mermaid-modal-content",r.innerHTML=e,t.append(n,r),document.body.appendChild(t),K=t,n.addEventListener("click",ge),t.addEventListener("click",s=>{s.target===t&&ge()});const o=s=>{s.key==="Escape"&&ge()};me=o,document.addEventListener("keydown",o),requestAnimationFrame(()=>t.classList.add("visible"))},Un=async(e,t)=>{const n=$t(t),r=Bt(e);if(!r)return;const o=vn(),a=(r.getAttribute(ke)??"")!==_,i=O(r),l=i?.querySelector("svg")instanceof SVGElement;if(r.getAttribute(De)===n&&!o&&!a&&l){Ge(r),Pe(r),Et(r),i&&(Ie(i),gt(i)),ee(r),te(r);return}if(r.getAttribute(de)==="1")return;const c=Xe(r,e);if(c){r.setAttribute(de,"1");try{if(await Nn(),!await qt()){p("load-unavailable");return}const g=await Pt();if(!g)return;const d=Pn(r,c);Ge(r),Pe(r),Et(r),r.setAttribute(L,"1");const C=`gm-mermaid-${Math.random().toString(36).slice(2,10)}`;try{const G=await g.render(C,n),mn=typeof G=="string"?G:G.svg;d.innerHTML=mn,gt(d),p("rendered",{codeLength:n.length})}catch(G){qn(d,String(G)),p("render-failed",{error:String(G)})}r.setAttribute(De,n),r.setAttribute(ke,_);const we=r.getAttribute(_e);Vt(r,we==="code"?"code":"diagram")}finally{r.removeAttribute(de)}}},Ye=()=>{if(!F)return;const e=document.querySelectorAll('code[data-test-id="code-content"], .formatted-code-block-internal-container code, .code-block pre code, code.code-container'),t=new Set;p("scan-start",{codeCount:e.length,renderEnabled:ue}),e.forEach(n=>{const r=Bt(n);if(!r)return;t.add(r),Ge(r),Pe(r);const o=J(n.textContent||""),s=W(n),a=r.closest('model-response, .model-response, [data-message-author-role="model"]'),i=!a||a.querySelector("message-actions")!==null;if(ue&&i&&(s==="mermaid"||On(s)&&Rn(o))){Un(n,o);return}r.getAttribute(L)==="1"?(qe(r,!1),p("mermaid-host-rolled-back",{language:s,codeLength:o.length})):(ee(r),te(r))}),document.querySelectorAll(`[${L}="1"]`).forEach(n=>{t.has(n)||qe(n,!1)}),p("scan-end",{activeHostCount:t.size,renderEnabled:ue})},Fn=()=>{document.querySelectorAll(".code-block, code-block").forEach(e=>{qe(e,!0)})},Ze=()=>{F&&(D!==null&&clearTimeout(D),D=window.setTimeout(()=>{D=null,Ye()},350))},Tt=()=>{[120,700,1600,3e3].forEach(e=>{const t=window.setTimeout(()=>{fe.delete(t),F&&(p("warmup-scan",{delay:e}),Ye())},e);fe.add(t)})},Hn=()=>{q||!document.body||(q=new MutationObserver(e=>{e.some(n=>{const r=n.target instanceof Element?n.target:n.target.parentElement;if(r?.closest(`.${w}, .${A}, .${ze}`))return!1;if(r?.closest(".code-block, code-block, model-response"))return!0;for(const o of Array.from(n.addedNodes))if((o instanceof Element?o:o.parentElement)?.closest(".code-block, code-block, model-response"))return!0;return!1})&&(p("mutation-detected",{count:e.length}),Ze())}),q.observe(document.body,{childList:!0,subtree:!0,characterData:!0}))};async function Ur(){if(F){Ze(),Tt();return}F=!0,Dn(),Hn(),Ye(),Tt(),qt(),p("start")}function Fr(){q&&(q.disconnect(),q=null),D!==null&&(clearTimeout(D),D=null),fe.forEach(e=>clearTimeout(e)),fe.clear(),Fn(),ge(),document.getElementById(Re)?.remove(),pe=!1,F=!1,p("stop")}function Hr(e){ue=e,p("render-toggle",{enabled:e}),Ze()}const jn=e=>e.hasManagedLayout||e.hasTranslatedAttr||e.hasProcessingAttr||e.hasSourceAttr||e.hasErrorAttr||e.hasModeAttr,Wn=e=>e.filter(t=>t.isManaged&&!t.isActive).map(t=>t.container),zn=e=>!!(e.textLength>0||e.hasImageLikeContent||e.hasTableLikeContent||e.hasCodeLikeContent),Vn=e=>!(!e.hasReadyTranslation||!e.hasResponseBodyContent||!e.hasResponseCompleted),Kn=e=>!e.isDisplayReady||!e.hasDisplayedTranslation,Xn=e=>e.toggleExpanded===!1||!(e.hasManagedLayout||e.hasExpandedClass||e.toggleExpanded===!0)||e.isAriaHidden||e.isHiddenAttr||e.ancestorHidden||e.isDisplayNone||e.isVisibilityHidden?!1:e.hasGeometry||e.hasManagedLayout,Yn=e=>e.hasExistingLayout?"keep-existing":e.hasIncomingSourceNodes?"before-first-source":"append-tail",Zn=e=>e.fullTextLength<=0||e.strongTextLength<=0||e.strongTextLength!==e.fullTextLength||e.textOutsideStrongLength>0?"normal":"strong",Qn=e=>{const t=e.filter(n=>!n.isInOriginalSlot).map(n=>n.node);return t.length>0?t:e.map(n=>n.node)},Jn=e=>e.replace(/(?:\\n|\n)+/g,`
`).replace(/[ \t]+\n/g,`
`).replace(/\n{2,}/g,`
`).trim(),er=e=>e.replace(/^(?:\\n|\n|\s)+$/g,"").replace(/(?:\\n\s*)+(?:en){2,}(?=\s|$)/gi,"").replace(/([\u4e00-\u9fff\u3002\uff0c\uff1b\uff1a\uff01\uff1f\uff09\u3011])(?:\s*(?:en){2,})(?=\s|$)/gi,"$1").replace(/(^|\s)(?:en){2,}(?=\s|$)/gi,"$1").replace(/(?:zh[-_ ]?cn\s*){2,}/gi,"").replace(/(^|[\s>〉])zh[-_ ]?cn(?=\s|$)/gi,"$1").replace(/[ \t]{2,}/g," ").trim(),Be="gm-thought-translation-style",b="gm-thought-translation-layout",S="gm-thought-original",m="gm-thought-translation",ye="data-gm-thought-translated",Qe="data-gm-thought-processing",Je="data-gm-thought-source",I="data-gm-thought-error",T="data-gm-thought-mode",tr=[`.${b}`,`[${ye}]`,`[${Qe}]`,`[${Je}]`,`[${I}]`,`[${T}]`].join(", "),nr=['[data-test-id="thoughts-content"]',".thoughts-content",".thoughts-content-expanded",".thoughts-streaming",".thoughts-container",".thoughts-wrapper"],rr=[":scope .markdown.markdown-main-panel",":scope > .markdown.markdown-main-panel",":scope .message-container message-content .markdown.markdown-main-panel",":scope .message-container message-content .markdown",":scope message-content .markdown.markdown-main-panel",":scope message-content .markdown",":scope .thought-content"],Z='[data-test-id="thoughts-content"], .thoughts-content, .thoughts-content-expanded, .thoughts-streaming, .thoughts-container, .thoughts-wrapper',or=".response-content",_t=["structured-content-container.model-response-text",".model-response-text"].join(", "),yt='pre, code-block, .code-block, [data-test-id*="code-block"], [data-test-id*="code_block"]',sr=[`.${m}`,"script","style",".katex","math","svg","button",'[role="button"]',"mat-icon",".google-symbols","pre","code-block",".code-block",'[data-test-id*="code-block"]','[data-test-id*="code_block"]'].join(", "),Kt=new Set(["P","LI","H1","H2","H3","H4","H5","H6","BLOCKQUOTE","TD","TH","DT","DD"]),ie=2800,St=260,ar=1,ir=3,lr=260,cr=2400,dr="[THINKING_DEBUG_TRACE]",Xt=400;let ne=!0,B=null,v=null,et="compare";const be=new Set,Ct=new Map,wt=new Map,Yt=new WeakMap,re=new WeakMap,N=new WeakMap,Zt=new WeakMap,Ee=new WeakMap,Q=new WeakMap,M=new WeakMap,H=new WeakSet,Lt=new WeakMap;let R=0,xt=1,At=0,Ne=0,vt=0,Me=0;const Te=(e,t)=>{},oe=(e,t={})=>{console.info(dr,e,t)},j=e=>{const t=Lt.get(e);if(t!==void 0)return`thought-${t}`;const n=xt;return xt+=1,Lt.set(e,n),`thought-${n}`},ur=e=>{const t=e.querySelector(`:scope > .${b}`),n=t?.querySelector(`:scope > .${S}`)??null,r=t?.querySelector(`:scope > .${m}`)??null,o=Array.from(e.children),s=o.filter(i=>!(i instanceof HTMLDivElement&&i.classList.contains(b))).length,a=E(r?.textContent||"").length;return{containerId:j(e),className:e.className,translated:M.has(e),processing:H.has(e),mode:e.getAttribute(T)??"",sourceLength:(re.get(e)??"").length,hasLayout:t instanceof HTMLDivElement,directChildCount:o.length,externalChildCount:s,originalChildCount:n?.children.length??0,translationTextLength:a}},h=(e,t,n={})=>{oe(t,{...ur(e),...n})},mr=(e,t={})=>{const n=Date.now();if(n-At<Xt){Ne+=1;return}oe("process-scheduled",{reason:e,suppressedCount:Ne,...t}),Ne=0,At=n},Qt=e=>e==="replace"?"replace":"compare",gr=e=>{e.setAttribute(T,et)},Jt=e=>jn({hasManagedLayout:e.querySelector(`:scope > .${b}`)instanceof HTMLDivElement,hasTranslatedAttr:e.hasAttribute(ye),hasProcessingAttr:e.hasAttribute(Qe),hasSourceAttr:e.hasAttribute(Je),hasErrorAttr:e.hasAttribute(I),hasModeAttr:e.hasAttribute(T)}),en=()=>{const e=new Set;return document.querySelectorAll(tr).forEach(t=>{const n=t.matches(Z)?t:t.closest(Z);n&&Jt(n)&&e.add(n)}),Array.from(e)},tt=()=>{const e=new Set;return an().forEach(t=>e.add(t)),en().forEach(t=>e.add(t)),Array.from(e)},hr=e=>e?zn({textLength:E(e.textContent||"").length,hasImageLikeContent:e.querySelector("img, video, audio, canvas")!==null,hasTableLikeContent:e.querySelector("table, figure")!==null,hasCodeLikeContent:e.querySelector("pre, code-block, .code-block")!==null}):!1,pr=e=>{const t=e.closest(or);if(t){const r=Array.from(t.children).find(o=>o instanceof HTMLElement&&o.matches(_t));if(r)return r}const n=e.closest(".response-container-content, .presented-response-container");return n?n.querySelector(_t):null},Ue=(e,t)=>Vn({hasReadyTranslation:t,hasResponseBodyContent:hr(pr(e)),hasResponseCompleted:En(e)}),fr=e=>{const t=e.querySelector(`:scope > .${b} > .${m}`);return t instanceof HTMLDivElement?E(t.textContent||"").length>0:!1},br=()=>{if(document.getElementById(Be))return;const e=document.createElement("style");e.id=Be,e.textContent=`
    .${b} {
      display: grid !important;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) !important;
      align-items: start !important;
      gap: 24px !important;
      width: 100% !important;
      max-width: 100% !important;
    }

    .${S},
    .${m} {
      min-width: 0 !important;
      width: 100% !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
      overflow: visible !important;
      color: inherit;
      white-space: pre-wrap !important;
      overflow-wrap: break-word !important;
      word-break: normal !important;
    }

    .${m}::before {
      content: '\\601D\\7EF4\\94FE\\7FFB\\8BD1';
      display: block;
      margin-bottom: 12px;
      color: inherit;
      opacity: 0.72;
      font: inherit;
      font-weight: 600;
    }

    .${m} {
      padding: 0 !important;
      margin: 0 !important;
      border: 0 !important;
      border-left: 1px solid rgba(0, 0, 0, 0.12) !important;
      background: #ffffff !important;
      border-radius: 0 !important;
      padding: 0 20px 0 24px !important;
      box-shadow: none !important;
      font: inherit !important;
      font-family: inherit !important;
      font-size: inherit !important;
      line-height: inherit !important;
    }

    .${m},
    .${m} * {
      font-family: inherit !important;
      font-size: inherit !important;
      line-height: inherit !important;
      max-width: 100% !important;
      color: inherit !important;
      background: transparent !important;
    }

    .${m} .gm-thought-translation-content {
      white-space: normal !important;
    }

    .${m} .gm-thought-translation-content p {
      margin: 0 0 1em 0 !important;
    }

    .${m} .gm-thought-translation-content p:last-child {
      margin-bottom: 0 !important;
    }

    .${m} .gm-thought-translation-code {
      margin: 0 0 1em 0 !important;
      padding: 12px 14px !important;
      border-radius: 10px !important;
      overflow-x: auto !important;
      white-space: pre !important;
      background: rgba(15, 23, 42, 0.06) !important;
      border: 0 !important;
    }

    .${m} .gm-thought-translation-code:last-child {
      margin-bottom: 0 !important;
    }

    .${m} .gm-thought-translation-code code {
      white-space: pre !important;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace !important;
      font-size: 0.92em !important;
      line-height: 1.5 !important;
    }

    .${m}[${I}="1"] {
      color: #b42318 !important;
    }

    .${m}[${I}="1"]::before {
      content: '\\601D\\7EF4\\94FE\\7FFB\\8BD1\\91CD\\8BD5\\4E2D';
    }

    [${T}="replace"] > .${b} {
      grid-template-columns: minmax(0, 1fr) !important;
      gap: 0 !important;
    }

    [${T}="replace"] .${S} {
      display: none !important;
    }

    [${T}="replace"] .${m} {
      border: 0 !important;
      border-left: 1px solid rgba(0, 0, 0, 0.12) !important;
      background: transparent !important;
      padding: 0 20px 0 24px !important;
      margin: 0 !important;
      font: inherit !important;
    }

    [${T}="replace"] .${m}::before {
      display: none !important;
    }

    @media (prefers-color-scheme: dark) {
      .${m} {
        background: #000000 !important;
        border-left-color: rgba(255, 255, 255, 0.14) !important;
      }

      .${m} .gm-thought-translation-code {
        background: rgba(148, 163, 184, 0.18) !important;
      }
    }

    @media (max-width: 1100px) {
      .${b} {
        grid-template-columns: minmax(0, 1fr) !important;
      }

      .${m} {
        border-left: 0 !important;
        border-top: 1px solid rgba(0, 0, 0, 0.12) !important;
        padding: 20px 0 0 0 !important;
      }
    }

    @media (max-width: 1100px) and (prefers-color-scheme: dark) {
      .${m} {
        border-top-color: rgba(255, 255, 255, 0.14) !important;
      }
    }
  `,document.head.appendChild(e)},E=e=>e.replace(/\u00a0/g," ").replace(/\r/g,"").replace(/[ \t]+\n/g,`
`).replace(/\n{3,}/g,`

`).trim(),X=e=>e.replace(/\u00a0/g," ").replace(/\r/g,"").replace(/\u200b/g,"").trim(),Nt=e=>e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"),Er=e=>{const t=e.split(/\n{2,}/),n=[];let r="";return t.forEach(o=>{const s=r?`${r}

${o}`:o;if(s.length<=ie){r=s;return}if(r&&n.push(r),o.length<=ie){r=o;return}for(let a=0;a<o.length;a+=ie)n.push(o.slice(a,a+ie));r=""}),r&&n.push(r),n.length>0?n:[e]},le=e=>E(e.textContent||""),Mt=e=>{let t=0,n=e;for(;n.parentNode;)n=n.parentNode,t+=1;return t},Tr=(e,t)=>{if(e===t)return 0;const n=e.compareDocumentPosition(t);return n&Node.DOCUMENT_POSITION_PRECEDING?1:n&Node.DOCUMENT_POSITION_FOLLOWING?-1:0},_r=e=>{const t=e.closest("model-thoughts, .model-thoughts");if(!t)return null;const n=t.querySelector("button.thoughts-header-button[aria-expanded]")??t.querySelector('button[aria-expanded][data-test-id*="thought"]')??t.querySelector('button[aria-expanded][class*="thought"]')??t.querySelector('[role="button"][aria-expanded][data-test-id*="thought"]');if(!n)return null;const r=n.getAttribute("aria-expanded");return r==="true"?!0:r==="false"?!1:null},tn=e=>{const t=_r(e);if(t===!1)return!1;const n=e.querySelector(`:scope > .${b}`)instanceof HTMLDivElement,r=window.getComputedStyle(e),o=e.getBoundingClientRect();return Xn({hasManagedLayout:n,hasExpandedClass:e.matches(".thoughts-content-expanded"),toggleExpanded:t,isAriaHidden:e.getAttribute("aria-hidden")==="true",isHiddenAttr:e.hasAttribute("hidden"),ancestorHidden:e.closest('[aria-hidden="true"], [hidden]')!==null,isDisplayNone:r.display==="none",isVisibilityHidden:r.visibility==="hidden",hasGeometry:o.width>1&&o.height>1})},yr=e=>{const t=new Set;e.matches(".markdown, .markdown.markdown-main-panel")&&t.add(e),rr.forEach(l=>{e.querySelectorAll(l).forEach(c=>t.add(c))});const n=Array.from(t).filter(l=>l.closest(`.${m}`)?!1:le(l).length>0),r=n.filter(l=>l.closest(`.${S}`)!==null).length,a=Qn(n.map(l=>({node:l,isInOriginalSlot:l.closest(`.${S}`)!==null}))).sort((l,c)=>Mt(l)-Mt(c)).filter((l,c,u)=>!u.some(g=>g!==l&&g.contains(l))).sort(Tr);if(a.length>0)return h(e,"source-nodes-selected",{candidateCount:t.size,withTextCount:n.length,originalSlotCandidateCount:r,selectedCount:a.length,selectedTextLength:a.reduce((l,c)=>l+le(c).length,0)}),a;const i=le(e)?[e]:[];return h(e,"source-nodes-fallback",{candidateCount:t.size,withTextCount:n.length,originalSlotCandidateCount:r,selectedCount:i.length,selectedTextLength:i.reduce((l,c)=>l+le(c).length,0)}),i},nn=e=>{const t=e.cloneNode(!0);return t instanceof HTMLElement?(t.querySelectorAll(sr).forEach(n=>n.remove()),t):null},nt=e=>{const t=nn(e);return t instanceof HTMLElement?E(t.textContent||""):""},rn=e=>{const t=nn(e);if(!(t instanceof HTMLElement))return"normal";const n=E(t.textContent||""),r=E(Array.from(t.querySelectorAll("strong, b")).map(a=>a.textContent||"").join(" ")),o=t.cloneNode(!0);if(!(o instanceof HTMLElement))return"normal";o.querySelectorAll("strong, b").forEach(a=>a.remove());const s=E(o.textContent||"");return Zn({fullTextLength:n.length,strongTextLength:r.length,textOutsideStrongLength:s.length})},Sr=e=>{if(e.matches("pre"))return e;const t=e.querySelector("pre");if(t)return t;if(e.matches(yt))return e;const n=e.querySelector(yt);return!n||Kt.has(e.tagName)&&nt(e).length>0?null:n},Cr=e=>{const t=e.matches("pre")?e:e.querySelector("pre");if(t)return X(t.textContent||"");const n=e.matches("code")?e:e.querySelector("code");return X(n?n.textContent||"":e.textContent||"")},Fe=(e,t,n,r,o="text",s="normal")=>{const a=o==="code"?X(r):Jn(r);return a?(e.push({id:`node-${t}-block-${n}`,text:a,kind:o,emphasis:o==="code"?"normal":s}),n+1):n},He=(e,t,n,r)=>{if(r.closest(`.${m}`)||r.matches("br"))return n;if(r.matches("ul, ol")){let s=n;return Array.from(r.children).forEach(a=>{a instanceof HTMLElement&&(s=He(e,t,s,a))}),s}const o=Sr(r);if(o)return Fe(e,t,n,Cr(o),"code");if(!Kt.has(r.tagName)&&r.children.length>0){let s=n;if(Array.from(r.children).forEach(a=>{a instanceof HTMLElement&&(s=He(e,t,s,a))}),s>n)return s}return Fe(e,t,n,nt(r),"text",rn(r))},wr=(e,t)=>{const n=[];let r=0;if(Array.from(e.childNodes).forEach(s=>{if(s.nodeType===Node.TEXT_NODE){r=Fe(n,t,r,s.textContent||"","text");return}s instanceof HTMLElement&&(r=He(n,t,r,s))}),n.length>0)return n;const o=nt(e);return o?[{id:`node-${t}-block-fallback`,text:o,kind:"text",emphasis:rn(e)}]:[]},Lr=e=>{const t=yr(e);if(t.length===0)return null;const n=t.flatMap((o,s)=>wr(o,s)),r=E(n.filter(o=>o.kind==="text").map(o=>o.text).join(`

`));return n.length===0?null:{sourceNodes:t,sourceText:r,blocks:n,signature:n.map(o=>`${o.kind}:${o.text}`).join("␟")}},xr=(e,t)=>`<div class="gm-thought-translation-content markdown markdown-main-panel">${e.map((r,o)=>{const s=t[o]??r.text;if(r.kind==="code"){const l=X(s);return l?`<pre class="gm-thought-translation-code"><code>${Nt(l)}</code></pre>`:""}const a=E(s);if(!a)return"";const i=Nt(a).replace(/\n/g,"<br>");return r.emphasis==="strong"?`<p><strong>${i}</strong></p>`:`<p>${i}</p>`}).join("")}</div>`,Ar=(e,t)=>t.reduce((n,r)=>{if(n)return n;if(r===e)return null;let o=r;for(;o&&o.parentElement!==e;)o=o.parentElement;return o?.parentElement===e?o:null},null),vr=(e,t,n)=>{gr(e);let r=e.querySelector(`:scope > .${b}`),o=r?.querySelector(`:scope > .${S}`)??null,s=r?.querySelector(`:scope > .${m}`)??null;const a=r instanceof HTMLDivElement,i=o instanceof HTMLDivElement,l=s instanceof HTMLDivElement,c=t.filter(d=>!(d instanceof HTMLElement)||d===e||!e.contains(d)||d.closest(`.${m}`)?!1:d.closest(`.${S}`)===null),u=Yn({hasExistingLayout:a,hasIncomingSourceNodes:c.length>0}),g=u==="before-first-source"?Ar(e,c):null;return r instanceof HTMLDivElement||(r=document.createElement("div"),r.className=b,o=document.createElement("div"),o.className=S,r.appendChild(o),s=document.createElement("div"),s.className=m,typeof n=="string"&&(s.innerHTML=n),r.appendChild(s),c.length>0?o.replaceChildren(...c):t.forEach(d=>{d instanceof HTMLElement&&d!==e&&e.contains(d)&&(d.closest(`.${m}`)||d.parentElement!==o&&o.appendChild(d))}),g?e.insertBefore(r,g):e.appendChild(r)),o instanceof HTMLDivElement||(o=document.createElement("div"),o.className=S,r.appendChild(o)),c.length>0?o.replaceChildren(...c):t.forEach(d=>{d instanceof HTMLElement&&d!==e&&e.contains(d)&&(d.closest(`.${m}`)||d.parentElement!==o&&o.appendChild(d))}),s instanceof HTMLDivElement||(s=document.createElement("div"),s.className=m,r.appendChild(s)),typeof n=="string"&&(s.innerHTML=n),h(e,"layout-synced",{sourceNodeCount:t.length,incomingSourceNodeCount:c.length,insertionMode:u,hadLayout:a,hadOriginalNode:i,hadTranslationNode:l,originalChildCountAfterSync:o.children.length,translationChildCountAfterSync:s.children.length}),{originalNode:o,translationNode:s}},on=e=>{e.querySelector(`:scope > .${b}`)instanceof HTMLDivElement&&(h(e,"translation-hidden-until-ready",{hasReadyTranslation:M.has(e)}),Se(e))},sn=(e,t,n)=>{const{translationNode:r}=vr(e,t.sourceNodes,n.html);r.removeAttribute(I),e.removeAttribute(I),e.setAttribute(ye,"1"),h(e,"translation-displayed",{blockCount:t.blocks.length,sourceLength:t.sourceText.length})},Se=e=>{const t=e.querySelector(`:scope > .${b}`);if(!(t instanceof HTMLDivElement))return;const n=t.querySelector(`:scope > .${S}`);if(n instanceof HTMLDivElement)for(;n.firstChild;)e.insertBefore(n.firstChild,t);t.remove(),h(e,"layout-restored")},an=()=>{const e=new Set;nr.forEach(o=>{document.querySelectorAll(o).forEach(s=>e.add(s))}),document.querySelectorAll(".thoughts-container .markdown.markdown-main-panel").forEach(o=>{const s=o.closest(Z)??o;e.add(s)});const t=Array.from(e).filter(tn),n=t.filter(o=>!t.some(s=>s!==o&&o.contains(s))),r=n.filter(o=>o.matches(".thoughts-content-expanded"));return r.length>0?r:n},k=e=>Yt.get(e)??0,rt=e=>{const t=k(e)+1;return Yt.set(e,t),t},ot=e=>{const t=Ee.get(e);t!==void 0&&(clearTimeout(t),Ee.delete(e))},ln=(e,t)=>{ot(e);const n=Math.max(30,t);h(e,"retry-scheduled",{delayMs:n});const r=window.setTimeout(()=>{Ee.delete(e),U("retry-timer",{containerId:j(e),delayMs:n})},n);Ee.set(e,r)},Ce=e=>{Q.delete(e)},Ot=(e,t)=>{const n=Q.get(e),r=n&&n.signature===t.signature?n.attempt+1:1;Q.set(e,{signature:t.signature,attempt:r});const o=Math.min(cr,lr*r);ln(e,o)},cn=e=>{rt(e),ot(e),Ce(e),H.delete(e),re.delete(e),N.delete(e),M.delete(e),e.removeAttribute(ye),e.removeAttribute(Qe),e.removeAttribute(Je),e.removeAttribute(I),h(e,"container-state-reset")},Nr=async e=>{const t=E(e);if(!t)return"";const n=Ct.get(t);if(n)return n;const r=Er(t),o=[];for(const a of r){const i=wt.get(a);if(i){o.push(i);continue}const l=await chrome.runtime.sendMessage({type:"gm.translateThought",text:a,targetLang:"zh-CN"});if(!l||l.ok!==!0){const u=l&&"error"in l?l.error:void 0;throw new Error(u||"translation_failed")}const c=E(er(l.translatedText));if(!c)throw new Error("translation_empty_chunk");wt.set(a,c),o.push(c)}const s=E(o.join(`

`));if(!s)throw new Error("translation_empty");return Ct.set(t,s),s},Oe=(e,t)=>xr(e,t),Mr=async(e,t,n)=>{const r=t.blocks,o=r.map(u=>u.kind==="code"?u.text:null),s=r.map((u,g)=>u.kind==="text"?g:-1).filter(u=>u>=0);if(s.length===0)return{incompleteCount:0,html:Oe(r,o)};let a=0,i=0;const l=Math.max(1,Math.min(ir,s.length)),c=async()=>{for(;;){const u=i;if(i+=1,u>=s.length)return;const g=s[u],d=r[g]?.text??"";if(!d){if(o[g]="",k(e)!==n)return;continue}try{const C=await Nr(d);if(k(e)!==n)return;o[g]=C}catch{a+=1,o[g]=null,Te("block-translation-failed",{blockId:t.blocks[g]?.id})}if(k(e)!==n)return}};return await Promise.all(Array.from({length:l},()=>c())),k(e)!==n?{incompleteCount:s.length,html:Oe(r,o)}:{incompleteCount:a,html:Oe(r,o)}},Or=(e,t)=>{const n=Date.now(),r=rt(e),o=!Kn({hasDisplayedTranslation:fr(e),isDisplayReady:Ue(e,!0)});N.delete(e),M.delete(e),re.set(e,t.sourceText),H.add(e),Zt.set(e,n),R+=1,o?h(e,"translation-refresh-preserved-display",{version:r,sourceNodeCount:t.sourceNodes.length,blockCount:t.blocks.length,sourceLength:t.sourceText.length}):on(e),h(e,"translation-started",{version:r,sourceNodeCount:t.sourceNodes.length,blockCount:t.blocks.length,sourceLength:t.sourceText.length,activeTranslationRequests:R,preserveDisplayedTranslation:o}),Mr(e,t,r).then(s=>{if(k(e)!==r)return;if(s.incompleteCount>0){N.set(e,t),Ot(e,t),Te("thought-translation-incomplete",{incompleteCount:s.incompleteCount,blockCount:t.blocks.length}),h(e,"translation-incomplete",{version:r,incompleteCount:s.incompleteCount,blockCount:t.blocks.length});return}const a={signature:t.signature,sourceText:t.sourceText,html:s.html};M.set(e,a),Ce(e),Ue(e,!0)?sn(e,t,a):h(e,"translation-ready-waiting-for-complete",{version:r,blockCount:t.blocks.length,sourceLength:t.sourceText.length}),Te("thought-translation-completed",{blockCount:t.blocks.length,sourceLength:t.sourceText.length}),h(e,"translation-completed",{version:r,blockCount:t.blocks.length,sourceLength:t.sourceText.length})}).catch(s=>{k(e)===r&&(N.set(e,t),Ot(e,t),h(e,"translation-failed",{version:r,error:String(s)}))}).finally(()=>{R=Math.max(0,R-1),H.delete(e),U("translation-finished",{containerId:j(e),version:r,activeTranslationRequests:R})})},st=()=>{tt().forEach(e=>{Jt(e)&&(Se(e),cn(e),e.removeAttribute(T))})},Rr=e=>{const t=Lr(e);if(!t){h(e,"process-no-payload");return}const n=Q.get(e);n&&n.signature!==t.signature&&Ce(e);const r=re.get(e)??"",o=H.has(e),s=Date.now(),a=r===t.sourceText,i=N.has(e),l=Q.get(e)?.signature===t.signature;let c=M.get(e);c&&c.signature!==t.signature&&(M.delete(e),c=void 0);const u=c?.signature===t.signature,g=Ue(e,u);if(u&&(g?(sn(e,t,c),h(e,"process-skip-ready-translation",{blockCount:t.blocks.length,sourceLength:t.sourceText.length})):(on(e),h(e,"process-wait-display-complete",{blockCount:t.blocks.length,sourceLength:t.sourceText.length})),!o&&!i&&!l))return;if(u&&!o&&a&&!i&&!l){h(e,"process-skip-same-source",{blockCount:t.blocks.length,sourceLength:t.sourceText.length});return}if(o){a||N.set(e,t),h(e,"process-pending-while-processing",{sameAsCurrentSource:a,blockCount:t.blocks.length,sourceLength:t.sourceText.length});return}if(R>=ar){N.set(e,t),h(e,"process-queued-concurrency",{activeTranslationRequests:R,blockCount:t.blocks.length,sourceLength:t.sourceText.length});return}const d=Zt.get(e)??0;if(r&&!a&&s-d<St){N.set(e,t);const C=St-(s-d);h(e,"process-throttled",{blockCount:t.blocks.length,sourceLength:t.sourceText.length,delayMs:C}),ln(e,C);return}h(e,"process-run-translation",{blockCount:t.blocks.length,sourceLength:t.sourceText.length,sameAsCurrentSource:a}),Or(e,t)},dn=()=>{if(!ne){st();return}const e=an(),t=en();Te("thought-container-scan",{count:e.length}),oe("container-scan",{count:e.length,containerIds:e.slice(0,6).map(n=>j(n)),managedCount:t.length,managedContainerIds:t.slice(0,6).map(n=>j(n))}),Wn(t.map(n=>({container:n,isActive:e.includes(n),isManaged:!0}))).forEach(n=>{h(n,"process-cleanup-stale-container"),Se(n),cn(n),n.removeAttribute(T)}),e.forEach(n=>Rr(n))},V=e=>(e instanceof Element?e:e.parentElement)?.closest(`.${m}`)!==null,Dr=e=>(e instanceof Element?e:e.parentElement)?.closest(Z)!==null,un=e=>{const t=e instanceof Element?e:e.parentElement;return t?t.closest(Z):null},ce=e=>{const t=un(e);return t?tn(t):!1},kr=e=>e.some(t=>{if(t.type==="attributes")return V(t.target)?!1:Dr(t.target)||z(t.target);if(t.type==="characterData")return V(t.target)?!1:ce(t.target)||z(t.target);if(V(t.target))return!1;if(ce(t.target)||z(t.target))return!0;for(const n of Array.from(t.addedNodes))if(!V(n)&&(ce(n)||z(n)))return!0;for(const n of Array.from(t.removedNodes))if(!V(n)&&(ce(n)||z(n)))return!0;return!1}),Ir=e=>{const t=Date.now();if(t-vt<Xt){Me+=1;return}const n=new Set,r=new Set;e.forEach(o=>{r.add(o.type);const s=un(o.target);s&&n.add(j(s))}),oe("mutation-batch",{mutationCount:e.length,mutationTypes:Array.from(r),containerIds:Array.from(n).slice(0,6),suppressedCount:Me}),Me=0,vt=t},U=(e="unspecified",t={})=>{if(!ne){st();return}mr(e,{hasDebounceTimer:v!==null,...t}),v!==null&&clearTimeout(v),v=window.setTimeout(()=>{v=null,dn()},160)},$r=()=>{[180,800,1800,3200].forEach(e=>{const t=window.setTimeout(()=>{be.delete(t),ne&&(oe("warmup-pass",{delayMs:e}),dn())},e);be.add(t)})},je=(e,t)=>{if(t!=="local")return;const n=e[y.THOUGHT_TRANSLATION_MODE];n&&(et=Qt(n.newValue),tt().forEach(r=>{rt(r),H.delete(r),M.delete(r),re.delete(r),Se(r),r.removeAttribute(T)}),U("storage-mode-change"))};function jr(){ne=!0,br(),chrome.storage.local.get([y.THOUGHT_TRANSLATION_MODE],e=>{et=Qt(e[y.THOUGHT_TRANSLATION_MODE]),U("startup-storage-sync")}),chrome.storage.onChanged.removeListener(je),chrome.storage.onChanged.addListener(je),!B&&document.body&&(B=new MutationObserver(e=>{kr(e)&&(Ir(e),U("mutation-observer",{mutationCount:e.length}))}),B.observe(document.body,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["class","style","aria-hidden","hidden"]})),U("start-thought-translation"),$r()}function Wr(){ne=!1,chrome.storage.onChanged.removeListener(je),B&&(B.disconnect(),B=null),v!==null&&(clearTimeout(v),v=null),be.forEach(e=>clearTimeout(e)),be.clear(),tt().forEach(e=>{ot(e),Ce(e)}),st(),document.getElementById(Be)?.remove()}export{y as S,Sn as _,qr as a,z as b,Pr as c,Tn as d,Wr as e,Ur as f,Hr as g,jr as h,Br as i,Gr as r,Fr as s};
